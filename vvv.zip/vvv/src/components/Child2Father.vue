<template>
    <h2 @click="abc">{{msg}}-{{mm}}-{{m}}</h2>
</template>
<script>
var x='alien'
export default {
    data(){
        return {
            msg:'i am he1'
        }
    },
    props:['mm','m'],
    mounted(){
        console.log(this.mm,this.m)
        // this.$emit('f',x)
    },
    methods:{
        abc(){
            this.$emit('f',x)
        }
    }
}
</script>
