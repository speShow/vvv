<template>
  <div id="app">
    <img src="./assets/logo.png">
    <hr>
    <c2f m="china" :mm="msg" @f="fun"></c2f>
    <router-view/>
  </div>
</template>

<script>
import Child2Father from '@/components/Child2Father'

export default {
  name: 'App',
  data(){
    return {
      msg:'hello'
    }
  },
  components:{
    c2f:Child2Father
  },
  methods:{
    fun(){
      console.log('x')
    }
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
